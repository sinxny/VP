//
// Button Toolbar
//
import Vue from 'vue'
import { BvPlugin, BvComponent } from '../../'

// Plugin
export declare const ButtonToolbarPlugin: BvPlugin

// Component: b-button-toolbar
export declare class BButtonToolbar extends BvComponent {}
