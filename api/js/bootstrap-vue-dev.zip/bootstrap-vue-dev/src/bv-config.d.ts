import Vue, { PluginFunction, PluginObject } from 'vue'
import { BvPlugin } from './'

export declare const BVConfigPlugin: BvPlugin
